CPackNuGet
----------

The documentation for the CPack NuGet generator has moved here: :cpack_gen:`CPack NuGet Generator`
